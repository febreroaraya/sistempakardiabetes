<footer id="footer" class="bg-one">
    <div class="footer-bottom">
        <h5>Copyright 2022. Sistem Pakar Deteksi Dini Penyakit Diabetes Militus.</h5>
        <h6>Design and Developed by <a href="">Themefisher</a></h6>
        <h6>Distributed by <a href="https://themewagon.com/">Themewagon</a> Website By Febrero Araya</h6>
    </div>
</footer> <!-- end footer -->


<!-- end Footer Area
    ========================================== -->



<!-- 
    Essential Scripts
    =====================================-->
<!-- Main jQuery -->
<script src="<?= base_url() ?>assets/user/plugins/jquery/jquery.min.js"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu5nZKbeK-WHQ70oqOWo-_4VmwOwKP9YQ"></script>
<script src="<?= base_url() ?>assets/user/plugins/google-map/gmap.js"></script>

<!-- Form Validation -->
<script src="<?= base_url() ?>assets/user/plugins/form-validation/jquery.form.js"></script>
<script src="<?= base_url() ?>assets/user/plugins/form-validation/jquery.validate.min.js"></script>

<!-- Bootstrap4 -->
<script src="<?= base_url() ?>assets/user/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- Parallax -->
<script src="<?= base_url() ?>assets/user/plugins/parallax/jquery.parallax-1.1.3.js"></script>
<!-- lightbox -->
<script src="<?= base_url() ?>assets/user/plugins/lightbox2/dist/js/lightbox.min.js"></script>
<!-- Owl Carousel -->
<script src="<?= base_url() ?>assets/user/plugins/slick/slick.min.js"></script>
<!-- filter -->
<script src="<?= base_url() ?>assets/user/plugins/filterizr/jquery.filterizr.min.js"></script>
<!-- Smooth Scroll js -->
<script src="<?= base_url() ?>assets/user/plugins/smooth-scroll/smooth-scroll.min.js"></script>

<!-- Custom js -->
<script src="<?= base_url() ?>assets/user/js/script.js"></script>

</body>

</html>